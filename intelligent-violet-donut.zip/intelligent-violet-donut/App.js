import React from 'react';
import { Text, SafeAreaView, StyleSheet, Image, View, TouchableOpacity, ScrollView } from 'react-native';
import { Card } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/FontAwesome';

function ProfileScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <View style={styles.profile}>
          <Image
            source={require('./imagens/recorte.jpeg')}
            style={styles.profileImage}
          />
          <View style={styles.profileText}>
            <Text style={styles.heading}>Lucas Oliveira</Text>
            <Text style={styles.subHeading}>Estudante de Análise e Desenvolvimento de Sistemas</Text>
            <Text style={styles.subHeading}>23 anos</Text>
            <Text style={styles.subHeading}>Faculdade Senac - Recife</Text>
          </View>
        </View>

        <View style={styles.menu}>
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate('Objetivo')}
          >
            <Icon name="bullseye" size={24} color="#3498db" />
            <Text style={styles.menuItemText}>Objetivo</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate('Habilidades')}
          >
            <Icon name="code" size={24} color="#3498db" />
            <Text style={styles.menuItemText}>Habilidades</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate('Experiencia')}
          >
            <Icon name="briefcase" size={24} color="#3498db" />
            <Text style={styles.menuItemText}>Experiência</Text>
          </TouchableOpacity>
        </View>

        <Card style={styles.card}>
          <Text style={styles.sectionHeading}>Bem-vindo ao meu currículo!</Text>
          <Text style={styles.paragraph}>
            Estudante dedicado de Análise e Desenvolvimento de Sistemas, apaixonado por projetos e em busca da minha primeira oportunidade profissional através de um estágio. Sou uma pessoa comunicativa e proativa, com familiaridade em Java,Net e MySQL. Demonstro facilidade em me adaptar a novos ambientes, tenho uma forte aptidão para o trabalho em equipe e carrego um grande senso de responsabilidade.
          </Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function ObjetivoScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Card style={styles.card}>
          <Text style={styles.sectionHeading}>Objetivo</Text>
          <Text style={styles.paragraph}>
            apaixonado por projetos e em busca da minha primeira oportunidade profissional através de um estágio. Sou uma pessoa comunicativa e proativa, com familiaridade em Java,Net e MySQL.
          </Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function HabilidadesScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Card style={styles.card}>
          <Text style={styles.sectionHeading}>Habilidades</Text>
          <View style={styles.iconContainer}>
            <Icon name="html5" size={40} color="#27ae60" style={styles.icon} />
            <Icon name="css3" size={40} color="#f39c12" style={styles.icon} />
            <Icon name="js" size={40} color="#2980b9" style={styles.icon} />
            <Icon name="python" size={40} color="#c0392b" style={styles.icon} />
            <Icon name="java" size={40} color="#8e44ad" style={styles.icon} />
          </View>
          <Text style={styles.paragraph}>
            - .Net{'\n'}
            - CSS{'\n'}
            - HTML{'\n'}
            - Python (CRUD){'\n'}
            - Java (Básico){'\n'}
          </Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function ExperienciaScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <Card style={styles.card}>
          <Text style={styles.sectionHeading}>Experiência</Text>
          <Text style={styles.paragraph}>
            Desenvolvimento de CRUD em Python{'\n'}
            Desenvolvimento de PWA para Loja de Relógios{'\n'}
            Desenvolvimento de PWA para Plataforma de Doações{'\n'}
          </Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Currículo de Lucas Oliveira" component={ProfileScreen} />
        <Stack.Screen name="Objetivo" component={ObjetivoScreen} />
        <Stack.Screen name="Habilidades" component={HabilidadesScreen} />
        <Stack.Screen name="Experiencia" component={ExperienciaScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  scrollViewContent: {
    flexGrow: 1,
  },
  profile: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#bdc3c7',
  },
  profileImage: {
    width: 90,
    height: 90,
    borderRadius: 45,
    marginRight: 15,
  },
  profileText: {
    flex: 1,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
    color: '#2c3e50',
  },
  subHeading: {
    fontSize: 16,
    marginBottom: 5,
    textAlign: 'center',
    color: '#34495e',
  },
  menu: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    backgroundColor: '#2980b9',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  menuItemText: {
    marginLeft: 5,
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  card: {
    margin: 20,
    padding: 20,
    borderRadius: 15,
    elevation: 3,
    backgroundColor: '#fff',
  },
  sectionHeading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#2c3e50',
  },
  paragraph: {
    fontSize: 16,
    color: '#34495e',
  },
  iconContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 10,
  },
  icon: {
    marginHorizontal: 10,
  },
});